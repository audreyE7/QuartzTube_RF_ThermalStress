# ANSYS Workbench Notes — Quartz Tube RF Heating (Axisymmetric)

- Geometry: 2D axisymmetric hollow cylinder, inner radius a, thickness t.
- BCs: Inner q'', outer convection h to T_inf. Structural: σ_r(a)=σ_r(b)=0, plane strain.
- Mesh: bias near inner wall; 50–100 elems across thickness.
- Outputs: T(r), σ_r, σ_θ, σ_z; correlate with analytic script.
