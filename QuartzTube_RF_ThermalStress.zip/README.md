# Quartz Tube + RF Coil — Thermal/Hoop Stress Map

Quick start:

```
python src/plots.py
```
Outputs saved in `figs/`.
